#https://hilaryparker.com/2014/04/29/writing-an-r-package-from-scratch/
library(roxygen2)

roxygen2md::roxygen2md()
roxygen2::roxygenise()

# once all files are complete
# devtools::document()

#then ctrl+shift+b to build

devtools::check()


pkgdown::build_site()

#devtools::install_github("SwampThingPaul/AnalystHelper")

devtools::build()
